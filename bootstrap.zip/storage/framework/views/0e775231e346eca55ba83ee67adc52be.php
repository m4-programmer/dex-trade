
<?php /**PATH C:\Users\USER\Desktop\cryptoinvestment\resources\views/home.blade.php ENDPATH**/ ?>