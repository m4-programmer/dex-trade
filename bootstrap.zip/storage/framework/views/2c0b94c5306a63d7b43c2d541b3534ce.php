<?php 
$items = [
    [
        'id' => 1,
        'plan_name' => 'Basic Plan',
        'amount_type' => 10,
        'minimum_amount' => 3000,
        'maximum_amount' => 6000,
        'amount' => 4500,
        'time' => ['name' => 'test'],
        'return_interest' => 3400,
        'interest_status' => 'percentage',
        'return_for' => 0,
        'capital_back' => 1,

    ],
    [
        'id' => 2,
        'plan_name' => 'Business Plan',
        'amount_type' => 0,
        'minimum_amount' => 3000,
        'maximum_amount' => 6000,
        'amount' => 4500,
        'time' => ['name' => 'test'],
        'return_interest' => 3400,
        'interest_status' => 'percentage',
        'return_for' => 0,
        'capital_back' => 1,

    ],
    [
        'id' => 3,
        'plan_name' => 'Premium Plan',
        'amount_type' => 0,
        'minimum_amount' => 3000,
        'maximum_amount' => 6000,
        'amount' => 4500,
        'time' => ['name' => 'test'],
        'return_interest' => 3400,
        'interest_status' => 'percentage',
        'return_for' => 0,
        'capital_back' => 1,

    ],
];
// $plans = json_decode(json_encode($items));
// dd($plans);
 ?>
<section id="investment" class="s-pt-100 s-pb-100 section-bg">
    <div class="container">

        <div class="row justify-content-center">
            <div class="col-lg-6 text-center">
                <div class="section-top">
                    <!-- <h2 class="section-title">Our Plans</h2> -->
                </div>
            </div>
        </div>

        <div class="row gy-4">
            <?php $__empty_1 = true; $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s" data-wow-duration="0.5s">
                    <div class="pricing-item">
                        <div class="top-part">
                            <div class="icon">
                                <i class="las la-gem"></i>
                            </div>
                            <div class="plan-name">
                                <span><?php echo e($plan->name); ?></span>
                            </div>
                           
                                <h4 class="plan-price">
                                    <?php echo e(__('Min')); ?>

                                    <?php echo e(number_format($plan->minimum_amount, 2)); ?> <sub>/ <?php echo e(@$gs->site_currency); ?></sub>
                                </h4>
                                <h4 class="plan-price">
                                    <?php echo e(__('Max')); ?>

                                    <?php if($plan->maximum_amount == 'Unlimited'): ?>
                                        <?php echo e(number_format($plan->maximum_amount, 2)); ?> <sub>/ <?php echo e(@$gs->site_currency); ?></sub>
                                    <?php else: ?>
                                        <?php echo e($plan->maximum_amount); ?>

                                </h4>
                            
                            
                            <ul class="check-list">
                                
                                <li><?php echo e(__('Return Amount ')); ?><?php echo e(number_format($plan->roi, 2)); ?>

                                    
                                        <?php echo e('%'); ?>

                                   
                                </li>
                                <li>
                                  <?php echo e($plan->duration); ?>

                                </li>
                               
                                <li><?php echo e(__('Capital Back')); ?> <?php echo e($plan->capital_back); ?></li>
                               


                            </ul>
                        </div>
                        <div class="bottom-part">
                            
                            
                                <a class="cmn-btn w-100 "
                                    href="<?php echo e(url('user.gateways', $plan->id)); ?>"><?php echo e(__('Choose Plan')); ?></a>
                                    
                                    <?php if(auth()->guard()->check()): ?>
                                        
                                    <button class="cmn-btn w-100 balance mt-3" data-plan="<?php echo e($plan); ?>"
                                        data-url=""><?php echo e(__('Invest Using Balance')); ?></button>
                                    <?php endif; ?>
                            
                            
                        </div>
                    </div><!-- pricing-item end -->
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Profit Calculator -->
<div class="modal fade" id="invest" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form action="<?php echo e(url('user.investmentplan.submit')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo e(__('Invest Now')); ?></h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="container-fluid">
                        <div class="form-group">
                            <label for=""><?php echo e(__('Invest Amount')); ?></label>
                            <input type="text" name="amount" class="form-control">
                            <input type="hidden" name="plan_id" class="form-control">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e(__('Close')); ?></button>
                    <button type="submit" class="btn cmn-btn"><?php echo e(__('Invest Now')); ?></button>
                </div>
            </div>
        </form>
    </div>
</div>

<?php $__env->startPush('script'); ?>
    <script>
        $(function() {
            'use strict'

            $('.balance').on('click', function() {
                const modal = $('#invest');
                modal.find('input[name=plan_id]').val($(this).data('plan').id);
                modal.modal('show')
            })
        })
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\Users\USER\Desktop\cryptoinvestment\resources\views/theme2/sections/plan.blade.php ENDPATH**/ ?>