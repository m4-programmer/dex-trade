

<footer class="footer-section has-bg-img">
    <div class="footer-top">
        <div class="map-el">
            <img src="<?php echo e(asset('asset/theme2/images/footer/map.png')); ?>" alt="">
        </div>
        <div class="container">
            <div class="row gy-5">
                <div class="col-lg-6">
                    <div class="footer-box">
                        <a href="/">
                            <h1>
                               <?php echo e($gs->sitename); ?>

                            </h1>
                        </a>
                        <p>Dextrade  is a real investment platform. Dextrade leading team has over 7 years of experience in trading, cryptocurrencies and software development for Networkers.</p>
                        <div class="footer-payment">
                            <h5><?php echo e(__('Payment Methods')); ?></h5>
                            <img src="<?php echo e(asset('asset/theme2/images/footer/payment-method.png')); ?>" alt="Payment Image">
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="footer-box">
                        <h4 class="title"><?php echo e(__('Useful Links')); ?></h4>
                        <ul class="footer-link-list">
                            <li> <a href="<?php echo e(url('/')); ?>"><?php echo e(__('HOME')); ?></a></li>
                            <li> <a href="<?php echo e(url('/about')); ?>"><?php echo e(__('ABOUT US')); ?></a></li>
                            <li> <a href="<?php echo e(url('/faq')); ?>"><?php echo e(__('FAQ')); ?></a></li>
                            <li> <a href="<?php echo e(url('/terms')); ?>"><?php echo e(__('TERMS')); ?></a></li>
                            <li> <a href="<?php echo e(url('/contact')); ?>"><?php echo e(__('CONTACT US')); ?></a></li>
                
                        </ul>
                    </div>
                </div>
               <!--  <div class="col-lg-3 col-md-4 col-sm-6">
                    <div class="footer-box">
                        <h4 class="title"><?php echo e(__('Our Services')); ?></h4>
                        <ul class="footer-link-list">
                            
                        </ul>
                    </div>
                </div> -->
                <div class="col-lg-3 col-md-6">
                    <div class="footer-box">
                        <h4 class="title"><?php echo e(__('Location')); ?></h4>
                        <p>
                            <?php echo e(@$gs->site_address); ?><br>
                            <strong><?php echo e(__('Phone')); ?>:</strong> <?php echo e($gs->site_phone); ?><br>
                            <strong><?php echo e(__('Email')); ?>:</strong> <?php echo e($gs->site_email); ?><br>
                        </p>
                        <ul class="social-links">
                           
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container">
            <p class="text-center mb-0">
                <?php if(@$gs->copyright): ?>
                    Copyright <?php echo e(__(@$gs->copyright)); ?> <?php echo e($gs->sitename); ?>  . All rights reserved.
                <?php endif; ?>
                
            </p>
        </div>
    </div>
</footer>
<?php /**PATH C:\Users\USER\Desktop\cryptoinvestment\resources\views/theme2/layout/footer.blade.php ENDPATH**/ ?>